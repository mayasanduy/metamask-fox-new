export default {
  root: './',
  build: {
    outDir: 'dist'
  }
};
