import React from 'react';
import ReactDOM from 'react-dom/client';
import FoxViewer from './FoxViewer';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<FoxViewer />);
